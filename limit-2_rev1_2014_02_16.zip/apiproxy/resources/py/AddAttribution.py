import xml.etree.ElementTree as ET
import urllib2

root = ET.fromstring(flow.getVariable("message.content"))

ET.SubElement(root, "attribution")
SetValue = root.find("attribution")
SetValue.text = "This weather is brought to you by Alex Koo and Yahoo! Weather"

output = ET.tostring(root)
flow.setVariable("message.content",output)
