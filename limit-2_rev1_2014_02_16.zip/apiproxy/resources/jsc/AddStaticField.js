/*var parsed=context.getVariable("message.content");
parsed.attribution='This weather is brought to you by Alex Koo and Yahoo! Weather';

context.setVariable("message.content",parsed.toXMLString());
*/








